package com.niit.shopingcart.util;

public class Util {
public String replace(String st, String ch1, String ch2) {
	return st.replace(ch1, ch2);
}

}
