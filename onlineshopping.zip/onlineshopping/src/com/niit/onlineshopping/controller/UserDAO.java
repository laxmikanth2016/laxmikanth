package com.niit.onlineshopping.controller;

public class UserDAO{
	public boolean isvalidcontroller(String UserID,String Password)
	{
		if (UserID.equals("NIIT")&& Password.equals("NIIT@123"))
		{
			return true;
		
		}
		else
		{
			return false;
		}
	}

}