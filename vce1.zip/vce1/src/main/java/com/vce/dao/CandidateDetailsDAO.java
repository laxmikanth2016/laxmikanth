package com.vce.dao;

import com.vce.model.CandidateDetails;

public interface CandidateDetailsDAO {
	
	public void saveOrUpdate(CandidateDetails candidateDetails);

}

