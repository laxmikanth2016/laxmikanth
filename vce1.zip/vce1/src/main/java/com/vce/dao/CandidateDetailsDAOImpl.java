package com.vce.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.vce.dao.CandidateDetailsDAO;
import com.vce.model.CandidateDetails;

@Repository("candidateDetailsDAO")
public class CandidateDetailsDAOImpl implements CandidateDetailsDAO{

	public CandidateDetailsDAOImpl()
	{
		
	}
	
	@Autowired
	private SessionFactory sessionFactory;


	public CandidateDetailsDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	@Transactional
	public void saveOrUpdate(CandidateDetails candidateDetails) {
		System.out.println("***********saveOrUpdate called in CandidateDetailsDAOImpl*********");
		Session s = sessionFactory.getCurrentSession();
		Transaction t = s.beginTransaction();
		System.out.println(candidateDetails.getAddress());
		sessionFactory.getCurrentSession().saveOrUpdate(candidateDetails);
		t.commit();
	}
}

