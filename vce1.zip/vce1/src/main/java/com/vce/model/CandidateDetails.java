package com.vce.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;
@Entity
@Table(name = "CANDIDATE_DETAILS")
public class CandidateDetails {
	@Id@GeneratedValue
	private int id;
	
	@NotNull(message="full name required")
	private String FullName;
	@NotNull(message="last name required")
	private String LastName;
	@NotNull(message="sex name required")
	private String Sex;
	@NotNull(message="marital status required")
	private String MaritalStatus;
	@NotNull(message="country name required")
	private String Country;
	@NotNull(message="city  required")
	private String City;
	@NotNull(message="DateOfBirth required")
	private String DateOfBirth;
	@NotNull(message="Email required")
	private String Email;
	@NotNull(message="Title required")
	private String Title;
	@NotNull(message="Nationality required")
	private String Nationality;
	@NotNull(message="PhoneNumber required")
	private String PhoneNumber;
	@NotNull(message="Industry required")
	private String Industry;
	@NotNull(message="InsertCareerObjective required")
	private String InsertCareerObjective;
	@NotNull(message="Address required")
	private String Address;
	@NotNull(message="UploadPhoto required")
	private String UploadPhoto;

public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getFullName() {
	return FullName;
}
public void setFullName(String fullName) {
	FullName = fullName;
}
public String getLastName() {
	return LastName;
}
public void setLastName(String lastName) {
	LastName = lastName;
}
public String getSex() {
	return Sex;
}
public void setSex(String sex) {
	Sex = sex;
}
public String getMaritalStatus() {
	return MaritalStatus;
}
public void setMaritalStatus(String maritalStatus) {
	MaritalStatus = maritalStatus;
}
public String getCountry() {
	return Country;
}
public void setCountry(String country) {
	Country = country;
}
public String getCity() {
	return City;
}
public void setCity(String city) {
	City = city;
}
public String getDateOfBirth() {
	return DateOfBirth;
}
public void setDateOfBirth(String dateOfBirth) {
	DateOfBirth = dateOfBirth;
}
public String getEmail() {
	return Email;
}
public void setEmail(String email) {
	Email = email;
}
public String getTitle() {
	return Title;
}
public void setTitle(String title) {
	Title = title;
}
public String getNationality() {
	return Nationality;
}
public void setNationality(String nationality) {
	Nationality = nationality;
}
public String getPhoneNumber() {
	return PhoneNumber;
}
public void setPhoneNumber(String phoneNumber) {
	PhoneNumber = phoneNumber;
}
public String getIndustry() {
	return Industry;
}
public void setIndustry(String industry) {
	Industry = industry;
}
public String getInsertCareerObjective() {
	return InsertCareerObjective;
}
public void setInsertCareerObjective(String insertCareerObjective) {
	InsertCareerObjective = insertCareerObjective;
}
public String getAddress() {
	return Address;
}
public void setAddress(String address) {
	Address = address;
}
public String getUploadPhoto() {
	return UploadPhoto;
}
public void setUploadPhoto(String uploadPhoto) {
	UploadPhoto = uploadPhoto;
}

	
@NotNull(message="NameOfInstitution required")
private String NameOfInstitution;	
@NotNull(message="Qualification required")
private String Qualification;
@NotNull(message="EduCityOrLocation required")
private String EduCityOrLocation;
@NotNull(message="EduStartDate required")
private String EduStartDate;
@NotNull(message="EduEndDate required")
private String EduEndDate;
@NotNull(message="EduDescription required")
private String EduDescription;
public String getEduStartDate() {
	return EduStartDate;
}
public void setEduStartDate(String eduStartDate) {
	EduStartDate = eduStartDate;
}
public String getEduEndDate() {
	return EduEndDate;
}
public void setEduEndDate(String eduEndDate) {
	EduEndDate = eduEndDate;
}
public String getEduDescription() {
	return EduDescription;
}
public void setEduDescription(String eduDescription) {
	EduDescription = eduDescription;
}
public void setEduCityOrLocation(String eduCityOrLocation) {
	EduCityOrLocation = eduCityOrLocation;
}


public String getNameOfInstitution() {
	return NameOfInstitution;
}
public void setNameOfInstitution(String nameOfInstitution) {
	NameOfInstitution = nameOfInstitution;
}
public String getQualification() {
	return Qualification;
}
public void setQualification(String qualification) {
	Qualification = qualification;
}
public String getEduCityOrLocation() {
	return EduCityOrLocation;
}



@NotNull(message="CompanyName required")
private String CompanyName;
@NotNull(message="Position required")
private String Position;
@NotNull(message="ExpCityOrLocation required")
private String ExpCityOrLocation;
@NotNull(message="ExpStartDate required")
private String ExpStartDate;
@NotNull(message="ExpEndDate required")
private String ExpEndDate;
@NotNull(message="ExpDescription required")
private String ExpDescription;

public String getCompanyName() {
	return CompanyName;
}
public void setCompanyName(String companyName) {
	CompanyName = companyName;
}
public String getPosition() {
	return Position;
}
public void setPosition(String position) {
	Position = position;
}
public String getExpCityOrLocation() {
	return ExpCityOrLocation;
}
public void setExpCityOrLocation(String expCityOrLocation) {
	ExpCityOrLocation = expCityOrLocation;
}
public String getExpStartDate() {
	return ExpStartDate;
}
public void setExpStartDate(String expStartDate) {
	ExpStartDate = expStartDate;
}
public String getExpEndDate() {
	return ExpEndDate;
}
public void setExpEndDate(String expEndDate) {
	ExpEndDate = expEndDate;
}
public String getExpDescription() {
	return ExpDescription;
}
public void setExpDescription(String expDescription) {
	ExpDescription = expDescription;
}


@NotNull(message="LanguageSkill required")
private String LanguageSkill;


@NotNull(message="TechnicalSkill required")
private String TechnicalSkill;
@NotNull(message="Reference required")
private String Reference;
@NotNull(message="SkillCategory required")
private String SkillCategory;
@NotNull(message="SkillDescription required")
private String SkillDescription;

public String getLanguageSkill() {
	return LanguageSkill;
}
public void setLanguageSkill(String languageSkill) {
	LanguageSkill = languageSkill;
}
public String getTechnicalSkill() {
	return TechnicalSkill;
}
public void setTechnicalSkill(String technicalSkill) {
	TechnicalSkill = technicalSkill;
}
public String getReference() {
	return Reference;
}
public void setReference(String reference) {
	Reference = reference;
}
public String getSkillCategory() {
	return SkillCategory;
}
public void setSkillCategory(String skillCategory) {
	SkillCategory = skillCategory;
}
public String getSkillDescription() {
	return SkillDescription;
}
public void setSkillDescription(String skillDescription) {
	SkillDescription = skillDescription;
}
}















	